# Sentimental Analysis Globe

3 important ways of intraction - 
1. Home page - Globe (essential)
2. Organisation 
3. Donate / Payment Gateway (3rd party)
4. Admin panel


## Things to do :
# Home Page 

Globe:
1. Live Feed 
2. Needs 
3. Magnitude
4. Location

Stats => Organisation => Donate (Payment) / Pick up location


